execute at @a run tag @e[type=minecraft:zombified_piglin, tag=!custom1, tag=!normal1, limit=1] add normal1

execute store result score z Maximo if entity @e[tag=custom1]

execute if score z Maximo matches ..999 run execute at @e[tag=normal1] run summon minecraft:zombified_piglin ~ ~ ~ {AngerTime:999999,CustomName:'[{"text":"Pigman Fear","bold":true,"color":"dark_gray"}]',CustomNameVisible:1b,HandItems:[{id:golden_sword,components:{enchantments:{levels:{mending:1}}},count:1}],ArmorItems:[{id:golden_boots,components:{enchantments:{levels:{protection:4}}},count:1},{id:golden_leggings,components:{enchantments:{levels:{protection:4}}},count:1},{id:golden_chestplate,components:{enchantments:{levels:{protection:4}}},count:1},{id:golden_helmet,components:{enchantments:{levels:{protection:4}}},count:1}],HandDropChances:[0f],ArmorDropChances:[0f,0f,0f,0f],Passengers:[{id:silverfish,Invulnerable:1b,Tags:["kill1"],PersistenceRequired:1b,Silent:1b}], Tags:[custom1]}
tp @e[tag=normal1] ~ -200 ~
kill @e[tag=normal1]

execute at @a run tag @e[type=minecraft:spider, tag=!custom, tag=!normal, limit=1] add normal

execute store result score z Maximo if entity @e[tag=custom]

execute if score z Maximo matches ..999 run execute at @e[tag=normal] run summon minecraft:spider ~ ~ ~ {CustomName:'[{"text":"Spider Fear","color":"dark_gray","bold":true}]',CustomNameVisible:1b,Health:32,HandItems:[{id:netherite_sword,components:{enchantments:{levels:{sharpness:10}}},count:1}],HandDropChances:[0f],attributes:[{id:"generic.movement_speed",base:0.9f},{id:"generic.max_health",base:32f}], Tags:[custom]}
tp @e[tag=normal] ~ -200 ~
kill @e[tag=normal]


execute at @a run tag @e[type=minecraft:ravager, tag=!custom2, tag=!normal2, limit=1] add normal2

execute store result score z Maximo if entity @e[tag=custom2]

execute if score z Maximo matches ..999 run execute at @e[tag=normal2] run summon minecraft:ravager ~ ~ ~ {CustomName:'[{"text":"Fearless Guardian #3","color":"dark_gray","bold":true}]',ArmorItems:[{},{id:leather_leggings,count:1,components:{trim:{pattern:rib,material:netherite},dyed_color:{rgb:4674881},custom_name:'["",{"text":"⊗Leggings⊗","italic":false,"color":"dark_red"}]',lore:['["",{"text":"?????????","italic":false}]'],unbreakable:{},attribute_modifiers:{modifiers:[{type:"generic.armor",amount:6,slot:legs,operation:add_value,id:1723104445202},{type:"generic.max_health",amount:4,slot:legs,operation:add_value,id:1723104445202},{type:"generic.armor_toughness",amount:5,slot:legs,operation:add_value,id:1723104445202}]}},count:1}],ArmorDropChances:[0f,0.1f],attributes:[{id:"generic.attack_damage",base:22f},{id:"generic.movement_speed",base:0.9f}], Tags:[custom2]}
tp @e[tag=normal2] ~ -200 ~
kill @e[tag=normal2]


execute at @a run tag @e[type=minecraft:zombie, tag=!custom3, tag=!normal3, limit=1] add normal3

execute store result score z Maximo if entity @e[tag=custom3]

execute if score z Maximo matches ..999 run execute at @e[tag=normal3] run summon minecraft:zombie ~ ~ ~ {IsBaby:1,CustomName:'[{"text":"Baby Fear","bold":true,"color":"dark_gray"}]',CustomNameVisible:1b,Health:30,HandItems:[{id:iron_sword,components:{enchantments:{levels:{sharpness:4}}},count:1}],ArmorItems:[{id:iron_boots,components:{enchantments:{levels:{protection:4}}},count:1},{id:iron_leggings,components:{enchantments:{levels:{protection:4}}},count:1},{id:iron_chestplate,components:{enchantments:{levels:{protection:4}}},count:1},{id:iron_helmet,components:{enchantments:{levels:{protection:4}}},count:1}],HandDropChances:[0f],ArmorDropChances:[0f,0f,0f,0f],attributes:[{id:"generic.max_health",base:30f}], Tags:[custom3]}
tp @e[tag=normal3] ~ -200 ~
kill @e[tag=normal3]


execute at @a run tag @e[type=minecraft:phantom, tag=!custom4, tag=!normal4, limit=1] add normal4

execute store result score z Maximo if entity @e[tag=custom4]

execute if score z Maximo matches ..999 run execute at @e[tag=normal4] run summon phantom ~ ~ ~ {CustomName:'[{"text":"Phamton Fear","bold":true,"color":"dark_gray"}]',CustomNameVisible:1b,HandItems:[{id:netherite_sword,components:{enchantments:{levels:{sharpness:5}}},count:1}],HandDropChances:[0f],attributes:[{id:"generic.attack_damage",base:24f}],Passengers:[{id:illusioner,CustomName:'[{"text":"Fearless Guardian #2","bold":true,"color":"dark_gray"}]',CustomNameVisible:1b,HandItems:[{id:bow,components:{enchantments:{levels:{power:30}}},count:1},{id:leather_boots,count:1,components:{trim:{pattern:rib,material:netherite},dyed_color:{rgb:4674881},custom_name:'["",{"text":"⊗Boots⊗","italic":false,"color":"dark_red"}]',lore:['["",{"text":"?????????","italic":false}]'],unbreakable:{},attribute_modifiers:{modifiers:[{type:"generic.armor",amount:4,slot:feet,operation:add_value,id:1723104129728},{type:"generic.max_health",amount:2,slot:feet,operation:add_value,id:1723104129728},{type:"generic.armor_toughness",amount:5,slot:feet,operation:add_value,id:1723104129728}]}},count:1}],HandDropChances:[0f,0.1f]}], Tags:[custom4]}
tp @e[tag=normal4] ~ -200 ~
kill @e[tag=normal4]


execute at @a run tag @e[type=minecraft:drowned, tag=!custom5, tag=!normal5, limit=1] add normal5

execute store result score z Maximo if entity @e[tag=custom5]

execute if score z Maximo matches ..999 run execute at @e[tag=normal5] run summon drowned ~ ~ ~ {CustomName:'[{"text":"Fearless Guardian #4","bold":true,"color":"dark_gray"}]',CustomNameVisible:1b,Health:45,HandItems:[{id:trident,count:1},{id:totem_of_undying,count:1}],ArmorItems:[{id:netherite_boots,components:{enchantments:{levels:{protection:2}}},count:1},{id:netherite_leggings,components:{enchantments:{levels:{protection:2}}},count:1},{id:leather_chestplate,count:1,components:{trim:{pattern:rib,material:netherite},dyed_color:{rgb:4674881},custom_name:'["",{"text":"⊗Chestplace⊗","italic":false,"color":"dark_red"}]',lore:['["",{"text":"?????????","italic":false}]'],unbreakable:{},attribute_modifiers:{modifiers:[{type:"generic.armor",amount:6,slot:chest,operation:add_value,id:1723104405358},{type:"generic.max_health",amount:4,slot:chest,operation:add_value,id:1723104405358},{type:"generic.armor_toughness",amount:5,slot:chest,operation:add_value,id:1723104405358}]}},count:1},{id:netherite_helmet,components:{enchantments:{levels:{protection:2}}},count:1}],HandDropChances:[0f,0f],ArmorDropChances:[0f,0f,0.1f,0f],attributes:[{id:"generic.max_health",base:45f}], Tags:[custom5]}
tp @e[tag=normal5] ~ -200 ~
kill @e[tag=normal5]


execute at @a run tag @e[type=minecraft:skeleton, tag=!custom6, tag=!normal6, limit=1] add normal6

execute store result score z Maximo if entity @e[tag=custom6]

execute if score z Maximo matches ..999 run execute at @e[tag=normal6] run summon skeleton ~ ~ ~ {CustomName:'[{"text":"Fearless Guardian #1","bold":true,"color":"dark_gray"}]',CustomNameVisible:1b,Health:50,HandItems:[{id:bow,components:{enchantments:{levels:{punch:5}}},count:1},{id:tipped_arrow,count:1,components:{potion_contents:{custom_color:11546150,custom_effects:[{id:instant_damage,duration:20,amplifier:0},{id:poison,duration:100,amplifier:4}]}},count:1}],ArmorItems:[{id:netherite_boots,count:1},{id:netherite_leggings,count:1},{id:netherite_chestplate,count:1},{id:leather_helmet,count:1,components:{trim:{pattern:rib,material:netherite},dyed_color:{rgb:4674881},custom_name:'["",{"text":"⊗Helmet⊗","italic":false,"color":"dark_red"}]',lore:['["",{"text":"???????????","italic":false}]'],unbreakable:{},attribute_modifiers:{modifiers:[{type:"generic.armor",amount:6,slot:head,operation:add_value,id:1722772203336},{type:"generic.max_health",amount:2,slot:head,operation:add_value,id:1722772203336}]}},count:1}],ArmorDropChances:[0f,0f,0f,0.1f],HandDropChances:[0f,0f],attributes:[{id:"generic.max_health",base:50f}], Tags:[custom6]}
tp @e[tag=normal6] ~ -200 ~
kill @e[tag=normal6]