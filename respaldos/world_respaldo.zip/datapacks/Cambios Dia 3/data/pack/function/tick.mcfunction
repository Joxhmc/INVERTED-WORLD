execute at @a run tag @e[type=minecraft:zombified_piglin, tag=!custom1, tag=!normal1, limit=1] add normal1

execute store result score z Maximo if entity @e[tag=custom1]

execute if score z Maximo matches ..999 run execute at @e[tag=normal1] run summon minecraft:zombified_piglin ~ ~ ~ {AngerTime:999999,CustomName:'[{"text":"Pigman Fear","bold":true,"color":"dark_gray"}]',CustomNameVisible:1b,HandItems:[{id:golden_sword,components:{enchantments:{levels:{mending:1}}},count:1}],ArmorItems:[{id:golden_boots,components:{enchantments:{levels:{protection:4}}},count:1},{id:golden_leggings,components:{enchantments:{levels:{protection:4}}},count:1},{id:golden_chestplate,components:{enchantments:{levels:{protection:4}}},count:1},{id:golden_helmet,components:{enchantments:{levels:{protection:4}}},count:1}],HandDropChances:[0f],ArmorDropChances:[0f,0f,0f,0f],Passengers:[{id:silverfish,Invulnerable:1b,Tags:["kill1"],PersistenceRequired:1b,Silent:1b}], Tags:[custom1]}
tp @e[tag=normal1] ~ -200 ~
kill @e[tag=normal1]

execute at @a run tag @e[type=minecraft:spider, tag=!custom, tag=!normal, limit=1] add normal

execute store result score z Maximo if entity @e[tag=custom]

execute if score z Maximo matches ..999 run execute at @e[tag=normal] run summon minecraft:spider ~ ~ ~ {CustomName:'[{"text":"Spider Fear","bold":true,"color":"dark_gray"}]',CustomNameVisible:1b,Health:32,HandItems:[{id:netherite_sword,components:{enchantments:{levels:{sharpness:10}}},count:1}],ArmorItems:[{},{},{},{id:ancient_debris,count:1}],ArmorDropChances:[0f,0f,0f,0.32f],HandDropChances:[0f],attributes:[{id:"generic.movement_speed",base:0.9f},{id:"generic.max_health",base:32f}], Tags:[custom]}
tp @e[tag=normal] ~ -200 ~
kill @e[tag=normal]
