tellraw @a {"text":"Hubo un reload!","bold":true,"color":"gold"}
